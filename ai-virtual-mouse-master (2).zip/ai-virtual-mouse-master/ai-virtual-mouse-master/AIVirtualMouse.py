"""
AI Virtual Mouse - gesture controlled cursor, click/drag, scroll, tab and
desktop switching.

This build focuses on cursor motion: lower latency and, more importantly,
*consistent* latency. The cursor no longer moves at the camera's frame rate.

HOW THE MOTION PATH WORKS NOW
    camera thread     grabs frames, stamps each one at capture time
    vision loop       lands ~25-60 Hz, jittery, produces position + velocity
    cursor driver     fixed 180 Hz thread, extrapolates between vision
                      updates and issues the actual OS move calls

    A dropped or slow frame no longer freezes the cursor - the driver keeps
    gliding along the last known velocity until fresh data arrives.

GESTURES
    1 finger  (index)                  -> move cursor
    2 fingers (index + middle)
          pinch them together          -> left click  (hold = drag)
          move hand up / down          -> scroll up / down
    3 fingers (+ ring), swipe L/R      -> previous / next browser tab
    4 fingers (+ pinky), swipe L/R     -> previous / next virtual desktop
    fist / other                       -> idle (cursor holds position)

KEYS
    q -> quit      c -> test click      d -> debug / timing overlay
    p -> preview off (saves 3-8 ms per frame; Ctrl+C to quit after that)

REQUIREMENTS
    pip install opencv-python mediapipe numpy pynput
    pip install autopy        (optional - lower-overhead cursor moves)

macOS: grant Accessibility + Input Monitoring to your terminal / Python.
Windows: to click inside an elevated window, run this script as admin too.
"""

import math
import os
import platform
import threading
import time
import urllib.request
from collections import deque

import cv2
import mediapipe as mp

# ============================================================
# OPTIONAL BACKENDS
# ============================================================

try:
    import autopy
    HAVE_AUTOPY = True
except Exception:
    HAVE_AUTOPY = False

try:
    from pynput.keyboard import Controller as KeyboardController, Key
    from pynput.mouse import Button, Controller as MouseController
    HAVE_PYNPUT = True
except Exception:
    HAVE_PYNPUT = False


# ============================================================
# SETTINGS
# ============================================================

W_CAM, H_CAM = 640, 480
TARGET_FPS = 60

# Inference resolution. Smaller = higher vision rate = less extrapolation.
# 192 on a weak CPU, 320 if tracking drifts.
DETECT_WIDTH = 256

SHOW_PREVIEW = True

# Control area margins (fraction of frame). Smaller = less hand travel.
MARGIN_X = 0.13
MARGIN_Y = 0.13

# --- Pointer source ---
# The index tip is the noisiest landmark on the hand. Blending a little of
# the DIP joint (landmark 7) into it cuts jitter without adding lag.
POINTER_BLEND = 0.25

# --- One Euro filter (position) ---
# MIN_CUTOFF governs steadiness when the hand is still: lower = calmer.
# BETA governs how fast the filter opens up when you move: higher = less lag
# during fast motion, but more jitter. Tune BETA first.
MIN_CUTOFF = 1.5          # Hz
BETA = 0.010              # per (screen px / sec)
D_CUTOFF = 1.0            # Hz, smoothing on the velocity estimate itself

# --- Cursor driver (output thread) ---
OUTPUT_HZ = 180.0         # fixed rate the OS cursor is updated at
TAU_OUT = 0.012           # output glide time constant (s); lower = snappier
LEAD_TIME = 0.030         # extra lead on top of measured data age (s)
MAX_AGE = 0.090           # never extrapolate further ahead than this (s)
MAX_LEAD_PX = 140.0       # or further than this in screen px
MIN_STEP_PX = 0.45        # skip OS calls smaller than this

# --- Click / pinch ---
PINCH_ON = 0.42           # index-middle tip distance / palm size
PINCH_OFF = 0.62
PINCH_ON_FRAMES = 2
PINCH_OFF_FRAMES = 2
PINCH_MIN_REACH = 1.25    # fist guard: both tips must reach this far out
DRAG_ENABLED = True

# --- Scroll ---
SCROLL_STEP_RATIO = 0.10
SCROLL_TICKS = 2
SCROLL_MAX_STEPS = 4
SCROLL_DEAD_RATIO = 0.012

# --- Swipes ---
SWIPE_WINDOW = 0.30
SWIPE_RATIO = 0.85
SWIPE_AXIS_BIAS = 1.4
SWIPE_COOLDOWN = 0.55

MODE_ENTER_FRAMES = 2
MODE_EXIT_FRAMES = 5
EXTEND_MARGIN = 0.12

MIN_DETECTION_CONFIDENCE = 0.6
MIN_PRESENCE_CONFIDENCE = 0.6
MIN_TRACKING_CONFIDENCE = 0.6

MODEL_FILE = "hand_landmarker.task"
MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/"
    "hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
)


# ============================================================
# TIMER RESOLUTION (Windows sleeps in ~15 ms steps by default)
# ============================================================

def sharpen_timer():
    if platform.system() != "Windows":
        return
    try:
        import ctypes
        ctypes.windll.winmm.timeBeginPeriod(1)
    except Exception:
        pass


def restore_timer():
    if platform.system() != "Windows":
        return
    try:
        import ctypes
        ctypes.windll.winmm.timeEndPeriod(1)
    except Exception:
        pass


# ============================================================
# MODEL
# ============================================================

def download_model():
    if os.path.exists(MODEL_FILE):
        return True
    print("MediaPipe hand model not found.\nDownloading hand_landmarker.task...")
    try:
        urllib.request.urlretrieve(MODEL_URL, MODEL_FILE)
        print("Hand model downloaded successfully.")
        return True
    except Exception as e:
        print("\nERROR: Could not download hand model.")
        print("Please check your internet connection.\nDetails:", e)
        return False


# ============================================================
# SYSTEM ACTIONS
# ============================================================

class Actions:
    def __init__(self):
        self.os_name = platform.system()
        self.mouse = MouseController() if HAVE_PYNPUT else None
        self.keyboard = KeyboardController() if HAVE_PYNPUT else None
        self.button_down = False
        self._reported = set()

        if not HAVE_AUTOPY and not HAVE_PYNPUT:
            raise RuntimeError(
                "No input backend available. Install pynput (pip install pynput)."
            )
        if not HAVE_PYNPUT:
            print("WARNING: pynput not installed - scroll, tab and desktop "
                  "gestures are disabled.")

    def _report(self, what, error):
        if what in self._reported:
            return
        self._reported.add(what)
        print(f"\nWARNING: '{what}' failed through the OS backend: {error}")
        if self.os_name == "Darwin":
            print("  macOS: System Settings > Privacy & Security > "
                  "Accessibility, enable your terminal / Python.")
        elif self.os_name == "Windows":
            print("  Windows: if the target window runs as administrator, "
                  "run this script as administrator too.")
        else:
            print("  Linux: pynput needs X11. On Wayland use Xorg or ydotool.")

    def screen_size(self):
        if HAVE_AUTOPY:
            w, h = autopy.screen.size()
            return float(w), float(h)
        try:
            import tkinter
            root = tkinter.Tk()
            root.withdraw()
            w, h = root.winfo_screenwidth(), root.winfo_screenheight()
            root.destroy()
            return float(w), float(h)
        except Exception:
            return 1920.0, 1080.0

    def move(self, x, y):
        try:
            if HAVE_AUTOPY:
                autopy.mouse.move(float(x), float(y))
            elif self.mouse:
                self.mouse.position = (int(x), int(y))
        except Exception as e:
            self._report("move", e)

    def press(self):
        if self.button_down:
            return
        try:
            if self.mouse:
                self.mouse.press(Button.left)
            elif HAVE_AUTOPY:
                autopy.mouse.toggle(autopy.mouse.Button.LEFT, True)
            self.button_down = True
        except Exception as e:
            self._report("press", e)

    def release(self):
        if not self.button_down:
            return
        try:
            if self.mouse:
                self.mouse.release(Button.left)
            elif HAVE_AUTOPY:
                autopy.mouse.toggle(autopy.mouse.Button.LEFT, False)
        except Exception as e:
            self._report("release", e)
        finally:
            self.button_down = False

    def scroll(self, ticks):
        if not self.mouse:
            return
        try:
            self.mouse.scroll(0, int(ticks))
        except Exception as e:
            self._report("scroll", e)

    def _combo(self, modifiers, key):
        if not self.keyboard:
            return
        try:
            for m in modifiers:
                self.keyboard.press(m)
            self.keyboard.press(key)
            self.keyboard.release(key)
            for m in reversed(modifiers):
                self.keyboard.release(m)
        except Exception as e:
            self._report("key combo", e)

    def next_tab(self):
        if HAVE_PYNPUT:
            self._combo([Key.ctrl], Key.tab)

    def prev_tab(self):
        if HAVE_PYNPUT:
            self._combo([Key.ctrl, Key.shift], Key.tab)

    def next_desktop(self):
        if not HAVE_PYNPUT:
            return
        if self.os_name == "Windows":
            self._combo([Key.cmd, Key.ctrl], Key.right)
        elif self.os_name == "Darwin":
            self._combo([Key.ctrl], Key.right)
        else:
            self._combo([Key.ctrl, Key.alt], Key.right)

    def prev_desktop(self):
        if not HAVE_PYNPUT:
            return
        if self.os_name == "Windows":
            self._combo([Key.cmd, Key.ctrl], Key.left)
        elif self.os_name == "Darwin":
            self._combo([Key.ctrl], Key.left)
        else:
            self._combo([Key.ctrl, Key.alt], Key.left)


# ============================================================
# CURSOR DRIVER  (fixed-rate output, decoupled from the camera)
# ============================================================

class CursorDriver:
    """
    Runs at OUTPUT_HZ regardless of what the camera is doing.

    Vision hands it a position, a velocity and the timestamp those belong to.
    Every tick the driver works out how old that data is, extrapolates the
    hand forward by (age + LEAD_TIME), and glides the cursor toward it.

    Result: the cursor updates on a steady clock instead of whenever a frame
    happens to finish, and a 60 ms inference hiccup produces a slightly less
    accurate cursor rather than a frozen one.

    Buttons, scrolls and key combos are queued here too, so they stay ordered
    relative to the moves around them, and no OS call ever blocks the vision
    loop.
    """

    def __init__(self, actions, screen_w, screen_h):
        self.actions = actions
        self.w = screen_w - 1.0
        self.h = screen_h - 1.0

        self._state = None          # (x, y, vx, vy, t_sample)
        self._active = False
        self._snap = True
        self._cmds = []
        self._lock = threading.Lock()

        self.cur_x = self.cur_y = None
        self.out_hz = 0.0           # measured, for the HUD

        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    # ---------- called from the vision loop ----------

    def track(self, x, y, vx, vy, t_sample):
        with self._lock:
            self._state = (x, y, vx, vy, t_sample)
            self._active = True

    def hold(self):
        """Stop driving the cursor; leave it exactly where it is."""
        with self._lock:
            self._active = False

    def snap(self):
        """Next update jumps instead of gliding (mode change, hand re-entry)."""
        with self._lock:
            self._snap = True
            self._state = None

    def press(self):
        self._push(("press", 0))

    def release(self):
        self._push(("release", 0))

    def scroll(self, ticks):
        self._push(("scroll", ticks))

    def key(self, name):
        self._push((name, 0))

    def _push(self, cmd):
        with self._lock:
            self._cmds.append(cmd)

    # ---------- worker ----------

    def _loop(self):
        a = self.actions
        table = {
            "press": lambda _: a.press(),
            "release": lambda _: a.release(),
            "scroll": a.scroll,
            "next_tab": lambda _: a.next_tab(),
            "prev_tab": lambda _: a.prev_tab(),
            "next_desktop": lambda _: a.next_desktop(),
            "prev_desktop": lambda _: a.prev_desktop(),
        }

        period = 1.0 / OUTPUT_HZ
        next_tick = time.perf_counter()
        last = next_tick
        hz = OUTPUT_HZ

        while self._running:
            # --- precise pace: sleep most of it, spin the last sliver ---
            next_tick += period
            while True:
                now = time.perf_counter()
                remaining = next_tick - now
                if remaining <= 0:
                    break
                if remaining > 0.002:
                    time.sleep(remaining - 0.0015)
                else:
                    time.sleep(0)       # yield, then re-check
            if next_tick < now - 0.25:  # fell badly behind, resync
                next_tick = now

            dt = max(1e-4, now - last)
            last = now
            hz += (1.0 / dt - hz) * 0.05
            self.out_hz = hz

            with self._lock:
                state = self._state
                active = self._active
                snap = self._snap
                self._snap = False
                cmds, self._cmds = self._cmds, []

            if active and state is not None:
                x, y, vx, vy, t_sample = state

                # How stale is this sample? Lead by exactly that much, plus a
                # fixed bias for the camera exposure + OS delivery delay.
                age = min(MAX_AGE, max(0.0, now - t_sample) + LEAD_TIME)
                lead_x = vx * age
                lead_y = vy * age
                lead = math.hypot(lead_x, lead_y)
                if lead > MAX_LEAD_PX:
                    scale = MAX_LEAD_PX / lead
                    lead_x *= scale
                    lead_y *= scale

                target_x = min(max(0.0, x + lead_x), self.w)
                target_y = min(max(0.0, y + lead_y), self.h)

                if snap or self.cur_x is None:
                    self.cur_x, self.cur_y = target_x, target_y
                    a.move(self.cur_x, self.cur_y)
                else:
                    # Time-constant glide: identical feel at any output rate.
                    alpha = 1.0 - math.exp(-dt / TAU_OUT)
                    nx = self.cur_x + (target_x - self.cur_x) * alpha
                    ny = self.cur_y + (target_y - self.cur_y) * alpha
                    if math.hypot(nx - self.cur_x, ny - self.cur_y) >= MIN_STEP_PX:
                        self.cur_x, self.cur_y = nx, ny
                        a.move(nx, ny)

            for name, arg in cmds:
                fn = table.get(name)
                if fn:
                    fn(arg)

    def stop(self):
        self._running = False
        self._thread.join(timeout=0.5)
        self.actions.release()


# ============================================================
# ONE EURO FILTER  (position + velocity, on real timestamps)
# ============================================================

class OneEuro2D:
    """
    Standard one-euro filter over a 2D point.

    Cutoff frequency rises with hand speed, so a still hand is heavily
    smoothed (no jitter) while a moving hand is barely smoothed (no lag).
    Also exposes the filtered velocity, which the driver uses to extrapolate.
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self.t = None
        self.x = self.y = None
        self.dx = self.dy = 0.0

    @staticmethod
    def _alpha(cutoff, dt):
        tau = 1.0 / (2.0 * math.pi * cutoff)
        return 1.0 / (1.0 + tau / dt)

    def update(self, x, y, t):
        """Returns (fx, fy, vx, vy) in the same units as the input."""
        if self.t is None:
            self.t = t
            self.x, self.y = x, y
            self.dx = self.dy = 0.0
            return x, y, 0.0, 0.0

        dt = t - self.t
        if dt <= 0.0:
            dt = 1e-3
        self.t = t

        # 1. filter the derivative
        a_d = self._alpha(D_CUTOFF, dt)
        raw_dx = (x - self.x) / dt
        raw_dy = (y - self.y) / dt
        self.dx += a_d * (raw_dx - self.dx)
        self.dy += a_d * (raw_dy - self.dy)

        # 2. speed-dependent cutoff on the position
        speed = math.hypot(self.dx, self.dy)
        cutoff = MIN_CUTOFF + BETA * speed
        a_p = self._alpha(cutoff, dt)
        self.x += a_p * (x - self.x)
        self.y += a_p * (y - self.y)

        return self.x, self.y, self.dx, self.dy


# ============================================================
# CAMERA  (timestamps every frame at capture, not at processing)
# ============================================================

class CameraStream:
    def __init__(self, src=0, width=W_CAM, height=H_CAM, fps=TARGET_FPS):
        backend = cv2.CAP_DSHOW if platform.system() == "Windows" else 0
        self.cap = cv2.VideoCapture(src, backend) if backend else cv2.VideoCapture(src)

        if not self.cap.isOpened():
            raise RuntimeError("Could not open webcam.")

        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_FPS, fps)
        for prop, value in (
            (cv2.CAP_PROP_BUFFERSIZE, 1),
            (cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG")),
        ):
            try:
                self.cap.set(prop, value)
            except Exception:
                pass

        self._frame = None
        self._stamp = 0.0
        self._lock = threading.Lock()
        self._new = threading.Event()
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def _loop(self):
        while self._running:
            ok, frame = self.cap.read()
            stamp = time.perf_counter()
            if not ok:
                time.sleep(0.005)
                continue
            with self._lock:
                self._frame = frame
                self._stamp = stamp
            self._new.set()

    def read(self, timeout=0.05):
        """Blocks until an unseen frame arrives. Returns (ok, frame, capture_t)."""
        if not self._new.wait(timeout):
            return False, None, 0.0
        self._new.clear()
        with self._lock:
            frame, stamp = self._frame, self._stamp
            self._frame = None
        if frame is None:
            return False, None, 0.0
        return True, frame, stamp

    def release(self):
        self._running = False
        self._thread.join(timeout=1.0)
        self.cap.release()


# ============================================================
# FINGER UTILITIES
# ============================================================

def dist(a, b):
    return math.hypot(b[0] - a[0], b[1] - a[1])


def hand_size(points):
    return max(1.0, dist(points[0], points[9]))


def fingers_up(points, palm_size):
    """[index, middle, ring, pinky], projected on the wrist -> palm axis."""
    wx, wy = points[0]
    mx, my = points[9]
    ax, ay = (mx - wx) / palm_size, (my - wy) / palm_size

    state = []
    for tip, pip, mcp in ((8, 6, 5), (12, 10, 9), (16, 14, 13), (20, 18, 17)):
        bx, by = points[mcp]
        tip_proj = (points[tip][0] - bx) * ax + (points[tip][1] - by) * ay
        pip_proj = (points[pip][0] - bx) * ax + (points[pip][1] - by) * ay
        state.append(int(tip_proj > pip_proj + EXTEND_MARGIN * palm_size))
    return state


def pinch_ratio(points, palm_size):
    """None when the fingers are not reaching out (a fist bunches tips too)."""
    if (dist(points[8], points[0]) / palm_size < PINCH_MIN_REACH or
            dist(points[12], points[0]) / palm_size < PINCH_MIN_REACH):
        return None
    return dist(points[8], points[12]) / palm_size


def gesture_mode(state):
    index, middle, ring, pinky = state
    if index and not middle and not ring and not pinky:
        return "MOVE"
    if index and middle and not ring and not pinky:
        return "TWO"
    if index and middle and ring and not pinky:
        return "THREE"
    if index and middle and ring and pinky:
        return "FOUR"
    return "IDLE"


# ============================================================
# PINCH STATE MACHINE
# ============================================================

class Pinch:
    def __init__(self):
        self.active = False
        self.on_count = 0
        self.off_count = 0

    def reset(self):
        self.active = False
        self.on_count = 0
        self.off_count = 0

    def update(self, ratio):
        """Returns 'down', 'up' or None."""
        if ratio is None:
            self.on_count = 0
            if self.active:
                self.off_count += 1
                if self.off_count >= PINCH_OFF_FRAMES:
                    self.active = False
                    self.off_count = 0
                    return "up"
            return None

        if not self.active:
            if ratio < PINCH_ON:
                self.on_count += 1
                if self.on_count >= PINCH_ON_FRAMES:
                    self.active = True
                    self.on_count = self.off_count = 0
                    return "down"
            else:
                self.on_count = 0
        else:
            if ratio > PINCH_OFF:
                self.off_count += 1
                if self.off_count >= PINCH_OFF_FRAMES:
                    self.active = False
                    self.off_count = 0
                    return "up"
            else:
                self.off_count = 0
        return None


# ============================================================
# DRAWING
# ============================================================

HAND_CONNECTIONS = (
    (0, 1), (1, 2), (2, 3), (3, 4),
    (0, 5), (5, 6), (6, 7), (7, 8),
    (5, 9), (9, 10), (10, 11), (11, 12),
    (9, 13), (13, 14), (14, 15), (15, 16),
    (13, 17), (17, 18), (18, 19), (19, 20),
    (0, 17),
)


def draw_hand(img, points):
    for start, end in HAND_CONNECTIONS:
        cv2.line(img, points[start], points[end], (0, 255, 0), 2)
    for i in (0, 4, 8, 9, 12, 16, 20):
        cv2.circle(img, points[i], 6 if i in (8, 12) else 4,
                   (0, 0, 255), cv2.FILLED)


# ============================================================
# SWIPE DETECTION
# ============================================================

def detect_swipe(history, palm_size):
    if len(history) < 3:
        return None

    t_now, x_now, y_now = history[-1]

    reference = None
    for sample in history:
        if t_now - sample[0] <= SWIPE_WINDOW:
            reference = sample
            break
    if reference is None or t_now - reference[0] < 0.04:
        return None

    dx = x_now - reference[1]
    dy = y_now - reference[2]

    if abs(dx) < palm_size * SWIPE_RATIO:
        return None
    if abs(dx) < abs(dy) * SWIPE_AXIS_BIAS:
        return None

    return "right" if dx > 0 else "left"


# ============================================================
# MAIN
# ============================================================

def main():
    if not download_model():
        return

    try:
        actions = Actions()
    except RuntimeError as e:
        print("ERROR:", e)
        return

    try:
        BaseOptions = mp.tasks.BaseOptions
        HandLandmarker = mp.tasks.vision.HandLandmarker
        HandLandmarkerOptions = mp.tasks.vision.HandLandmarkerOptions
        RunningMode = mp.tasks.vision.RunningMode

        detector = HandLandmarker.create_from_options(HandLandmarkerOptions(
            base_options=BaseOptions(model_asset_path=MODEL_FILE),
            running_mode=RunningMode.VIDEO,
            num_hands=1,
            min_hand_detection_confidence=MIN_DETECTION_CONFIDENCE,
            min_hand_presence_confidence=MIN_PRESENCE_CONFIDENCE,
            min_tracking_confidence=MIN_TRACKING_CONFIDENCE,
        ))
    except Exception as e:
        print("\nERROR: Could not initialize MediaPipe.\n", e)
        return

    try:
        camera = CameraStream()
    except RuntimeError as e:
        print("ERROR:", e)
        detector.close()
        return

    W_SCREEN, H_SCREEN = actions.screen_size()

    sharpen_timer()
    driver = CursorDriver(actions, W_SCREEN, H_SCREEN)
    motion = OneEuro2D()
    pinch = Pinch()

    print("Screen size:", int(W_SCREEN), "x", int(H_SCREEN))
    print("Platform:", actions.os_name)
    print("Cursor backend:", "autopy" if HAVE_AUTOPY else "pynput")
    print(f"Inference width: {DETECT_WIDTH}   Output rate: {int(OUTPUT_HZ)} Hz")
    print("q = quit, c = test click, p = preview off, d = debug.")

    last_swipe_time = 0.0
    scroll_anchor_y = None
    scroll_accumulator = 0.0
    swipe_history = deque(maxlen=48)

    mode = candidate_mode = "IDLE"
    candidate_count = 0

    status_text = ""
    status_until = 0.0
    show_preview = SHOW_PREVIEW
    show_debug = False
    debug_line = ""

    prev_stamp = None
    cam_hz = 30.0
    infer_ms = 0.0
    jitter_ms = 0.0

    span_x = 1.0 - 2.0 * MARGIN_X
    span_y = 1.0 - 2.0 * MARGIN_Y

    def to_screen(nx, ny):
        """Normalized, already-mirrored hand coords -> screen pixels."""
        cx = min(max(nx, MARGIN_X), 1.0 - MARGIN_X)
        cy = min(max(ny, MARGIN_Y), 1.0 - MARGIN_Y)
        return ((cx - MARGIN_X) / span_x * (W_SCREEN - 1),
                (cy - MARGIN_Y) / span_y * (H_SCREEN - 1))

    def drive(nx, ny, stamp):
        """Filter a normalized point and hand position + velocity to the driver."""
        tx, ty = to_screen(nx, ny)
        fx, fy, vx, vy = motion.update(tx, ty, stamp)
        driver.track(fx, fy, vx, vy, stamp)

    def handle_key():
        nonlocal show_preview, show_debug
        key = (cv2.waitKey(1) & 0xFF) if show_preview else 255
        if key == ord("q"):
            return False
        if key == ord("c"):
            print("Test click sent.")
            driver.press()
            driver.release()
        elif key == ord("d"):
            show_debug = not show_debug
        elif key == ord("p"):
            show_preview = False
            cv2.destroyAllWindows()
            print("Preview off. Press Ctrl+C in this terminal to quit.")
        return True

    try:
        while True:
            success, frame, stamp = camera.read()
            if not success:
                if not handle_key():
                    break
                continue

            h_cam, w_cam = frame.shape[:2]

            # Frame pacing stats, measured from capture time so processing
            # jitter does not pollute the velocity estimate.
            if prev_stamp is not None:
                gap = stamp - prev_stamp
                cam_hz += (1.0 / max(1e-3, gap) - cam_hz) * 0.1
                jitter_ms += (abs(gap - 1.0 / cam_hz) * 1000.0 - jitter_ms) * 0.1
            prev_stamp = stamp

            now = time.perf_counter()

            # ---- inference on a small RGB copy ----
            scale = DETECT_WIDTH / float(w_cam)
            small = (cv2.resize(frame, (DETECT_WIDTH, int(h_cam * scale)),
                                interpolation=cv2.INTER_AREA)
                     if scale < 1.0 else frame)
            rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)

            t0 = time.perf_counter()
            result = detector.detect_for_video(
                mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb),
                int(stamp * 1000))
            infer_ms += ((time.perf_counter() - t0) * 1000.0 - infer_ms) * 0.1

            img = cv2.flip(frame, 1) if show_preview else None

            if result.hand_landmarks:
                lms = result.hand_landmarks[0]
                norm = [(1.0 - lm.x, lm.y) for lm in lms]       # mirrored
                points = [(int(x * w_cam), int(y * h_cam)) for x, y in norm]

                palm_size = hand_size(points)
                state = fingers_up(points, palm_size)
                ratio = pinch_ratio(points, palm_size)
                raw_mode = gesture_mode(state)

                # A pinch curls the fingers, which would otherwise read as
                # MOVE or IDLE and kill the click - force TWO instead.
                if pinch.active or (ratio is not None and ratio < PINCH_OFF):
                    raw_mode = "TWO"

                if raw_mode == candidate_mode:
                    candidate_count += 1
                else:
                    candidate_mode = raw_mode
                    candidate_count = 1

                needed = MODE_ENTER_FRAMES if mode == "IDLE" else MODE_EXIT_FRAMES
                if (candidate_count >= needed and mode != candidate_mode
                        and not pinch.active):
                    mode = candidate_mode
                    scroll_anchor_y = None
                    scroll_accumulator = 0.0
                    swipe_history.clear()
                    motion.reset()
                    if mode in ("MOVE", "TWO"):
                        driver.snap()   # re-anchor without sliding across
                    else:
                        driver.hold()

                if show_preview:
                    draw_hand(img, points)

                # ---------------- MOVE ----------------
                if mode == "MOVE":
                    # Blend the tip with the DIP joint: same reach, less noise.
                    px = norm[8][0] + (norm[7][0] - norm[8][0]) * POINTER_BLEND
                    py = norm[8][1] + (norm[7][1] - norm[8][1]) * POINTER_BLEND
                    drive(px, py, stamp)

                    if show_preview:
                        cv2.circle(img, points[8], 12, (255, 0, 255), cv2.FILLED)
                    status_text, status_until = "MOVING", now + 0.1

                # ---------------- TWO: click / drag / scroll ----------------
                elif mode == "TWO":
                    center = ((points[8][0] + points[12][0]) // 2,
                              (points[8][1] + points[12][1]) // 2)

                    edge = pinch.update(ratio)
                    if edge == "down":
                        driver.press()
                        scroll_anchor_y = None
                        scroll_accumulator = 0.0
                        motion.reset()
                        status_text, status_until = "CLICK", now + 0.3
                    elif edge == "up":
                        driver.release()
                        driver.hold()
                        scroll_anchor_y = None
                        status_text, status_until = "RELEASE", now + 0.2

                    if show_preview:
                        cv2.line(img, points[8], points[12],
                                 (0, 255, 0) if pinch.active else (255, 255, 0), 3)

                    if pinch.active:
                        if DRAG_ENABLED:
                            drive((norm[8][0] + norm[12][0]) * 0.5,
                                  (norm[8][1] + norm[12][1]) * 0.5, stamp)
                        if show_preview:
                            cv2.circle(img, center, 16, (0, 255, 0), cv2.FILLED)
                        if now > status_until:
                            status_text, status_until = "HOLDING (drag)", now + 0.1
                    else:
                        driver.hold()       # cursor parks during scrolling

                        if scroll_anchor_y is None:
                            scroll_anchor_y = center[1]

                        delta = (scroll_anchor_y - center[1]) / palm_size
                        scroll_anchor_y = center[1]

                        if abs(delta) > SCROLL_DEAD_RATIO:
                            scroll_accumulator += delta

                        steps = int(scroll_accumulator / SCROLL_STEP_RATIO)
                        if steps != 0:
                            steps = max(-SCROLL_MAX_STEPS,
                                        min(SCROLL_MAX_STEPS, steps))
                            driver.scroll(steps * SCROLL_TICKS)
                            scroll_accumulator -= steps * SCROLL_STEP_RATIO
                            status_text = "SCROLL UP" if steps > 0 else "SCROLL DOWN"
                            status_until = now + 0.25
                        elif now > status_until:
                            status_text, status_until = "SCROLL / CLICK", now + 0.1

                        if show_preview:
                            cv2.arrowedLine(img, (center[0], center[1] + 40),
                                            (center[0], center[1] - 40),
                                            (0, 255, 255), 2, tipLength=0.3)

                # ---------------- THREE / FOUR ----------------
                elif mode in ("THREE", "FOUR"):
                    driver.release()
                    driver.hold()
                    pinch.reset()
                    swipe_history.append((stamp, float(points[9][0]),
                                          float(points[9][1])))

                    direction = None
                    if now - last_swipe_time > SWIPE_COOLDOWN:
                        direction = detect_swipe(swipe_history, palm_size)

                    if direction:
                        last_swipe_time = now
                        swipe_history.clear()
                        right = direction == "right"
                        if mode == "THREE":
                            driver.key("next_tab" if right else "prev_tab")
                            status_text = "NEXT TAB" if right else "PREVIOUS TAB"
                        else:
                            driver.key("next_desktop" if right else "prev_desktop")
                            status_text = ("NEXT DESKTOP" if right
                                           else "PREVIOUS DESKTOP")
                        status_until = now + 0.6
                    elif now > status_until:
                        status_text = ("TAB SWIPE" if mode == "THREE"
                                       else "DESKTOP SWIPE")
                        status_until = now + 0.1

                    if show_preview:
                        px_, py_ = points[9]
                        cv2.arrowedLine(img, (px_ - 50, py_), (px_ + 50, py_),
                                        (255, 200, 0), 2, tipLength=0.3)

                else:
                    driver.release()
                    driver.hold()
                    pinch.reset()
                    if now > status_until:
                        status_text, status_until = "IDLE", now + 0.1

                if show_debug:
                    debug_line = (
                        f"cam {cam_hz:4.1f}Hz  jit {jitter_ms:4.1f}ms  "
                        f"infer {infer_ms:4.1f}ms  out {driver.out_hz:5.1f}Hz  "
                        f"ratio={'--' if ratio is None else f'{ratio:.2f}'}  "
                        f"mode={mode}")

            else:
                driver.release()
                driver.hold()
                pinch.reset()
                motion.reset()
                driver.snap()
                scroll_anchor_y = None
                scroll_accumulator = 0.0
                swipe_history.clear()
                mode = candidate_mode = "IDLE"
                candidate_count = 0
                debug_line = "no hand"

            # ---------------- HUD ----------------
            if show_preview:
                mxp, myp = int(w_cam * MARGIN_X), int(h_cam * MARGIN_Y)
                cv2.rectangle(img, (mxp, myp), (w_cam - mxp, h_cam - myp),
                              (255, 0, 255), 2)
                cv2.putText(img, f"FPS: {int(cam_hz)}", (20, 40),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
                if status_text and now <= status_until:
                    cv2.putText(img, status_text, (20, 100),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
                if show_debug:
                    cv2.putText(img, debug_line, (14, h_cam - 45),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 255, 0), 1)
                cv2.putText(img,
                            "1:move  2:pinch=click/hold=drag  3:tabs  4:desktops",
                            (20, h_cam - 20), cv2.FONT_HERSHEY_SIMPLEX,
                            0.55, (200, 200, 200), 1)
                cv2.imshow("AI Virtual Mouse", img)

            if not handle_key():
                break

    except KeyboardInterrupt:
        print("\nProgram stopped.")

    finally:
        driver.stop()
        camera.release()
        cv2.destroyAllWindows()
        detector.close()
        restore_timer()
        print("AI Virtual Mouse closed.")


# ============================================================
# START
# ============================================================

if __name__ == "__main__":
    main()
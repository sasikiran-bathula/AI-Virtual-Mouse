## AI Virtual Mouse

> Developed an AI-based approach for controlling the mouse movement using Python and openCV with real-time camera that detects hand landmarks, tracks gesture patterns instead of a physical mouse.

## Dependencies  -
> Please install all the required dependencies.
* openCV - (For image processing and drawing)
* mediapipe - (For Hand Tracking)
* autopy - (For controlling the mouse movement and click)
* numpy
* time 
* urllib.request
* math
* os

## Installation

To setup the system for development on your local machine, please follow the instructions below:

1. open terminal ( click search bar and enter  >terminal    then open cmd in vs studio )

2. Download all dependencies

3. Enter     ""  cd ai-virtual-mouse-master  ""

4. At last finally enter          "" python AIVirtualMouse.py  ""


   

